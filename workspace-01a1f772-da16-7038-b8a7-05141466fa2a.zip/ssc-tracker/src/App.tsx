import { useCallback, useEffect, useState } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from './lib/supabase';
import {
  addPendingSession,
  clearLocalActiveSession,
  getCachedProfile,
  getCachedSessions,
  getLocalActiveSession,
  getPendingSessions,
  removePendingSession,
  saveCachedProfile,
  saveCachedSessions,
  setLocalActiveSession,
} from './lib/idb';
import { getDhakaDateString } from './lib/time';
import type { ActiveSession, NavTab, Profile, StudyMode, StudySession } from './types/study';
import { AuthScreen } from './components/AuthScreen';
import { Onboarding } from './components/Onboarding';
import { Dashboard } from './components/Dashboard';
import { StudyTimer } from './components/StudyTimer';
import { ProgressView } from './components/ProgressView';
import { RankingView } from './components/RankingView';
import { ProfileView } from './components/ProfileView';
import { BottomNav } from './components/BottomNav';
import { FoxMascot } from './components/FoxMascot';

export function App() {
  const [authSession, setAuthSession] = useState<Session | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isOnline, setIsOnline] = useState<boolean>(navigator.onLine);
  const [pendingCount, setPendingCount] = useState<number>(0);

  // Track online/offline status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Auth listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setAuthSession(data.session);
      setAuthLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setAuthSession(session);
      if (!session) {
        setProfile(null);
        setSessions([]);
        setActiveSession(null);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  // Sync pending offline sessions to Supabase
  const syncPendingSessions = useCallback(async (userId: string) => {
    const pending = await getPendingSessions(userId);
    setPendingCount(pending.length);
    if (!navigator.onLine || pending.length === 0) return;

    for (const s of pending) {
      const { error } = await supabase
        .from('study_sessions')
        .upsert(s, { onConflict: 'id', ignoreDuplicates: true });
      if (!error) {
        await removePendingSession(s.id);
      }
    }
    const remaining = await getPendingSessions(userId);
    setPendingCount(remaining.length);
  }, []);

  // Load user data (profile, active session, 4-month sessions)
  const loadUserData = useCallback(
    async (session: Session) => {
      const userId = session.user.id;

      // 1. Restore local active session immediately for zero-delay timer recovery
      const localActive = await getLocalActiveSession(userId);
      if (localActive) {
        setActiveSession(localActive);
      }

      // 2. Load cached profile & sessions for instant offline-first UI
      const cachedProf = await getCachedProfile(userId);
      if (cachedProf) {
        setProfile(cachedProf);
        setShowOnboarding(!cachedProf.onboarding_completed);
      }
      const cachedSess = await getCachedSessions(userId);
      if (cachedSess.length > 0) {
        setSessions(cachedSess);
      }

      if (!navigator.onLine) return;

      // 3. Sync any pending offline sessions first
      await syncPendingSessions(userId);

      // 4. Enforce 4-month retention on server
      await supabase.rpc('purge_expired_study_sessions');

      // 5. Fetch or create profile
      const { data: profData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (profData) {
        setProfile(profData as Profile);
        setShowOnboarding(!profData.onboarding_completed);
        await saveCachedProfile(profData as Profile);
      } else {
        const meta = session.user.user_metadata || {};
        const newProfile: Profile = {
          id: userId,
          student_name: meta.student_name || 'শিক্ষার্থী',
          ssc_batch: meta.ssc_batch || 'SSC 27',
          school_name: meta.school_name || null,
          avatar_id: 'fox-classic',
          onboarding_completed: false,
        };
        await supabase.from('profiles').upsert(newProfile);
        setProfile(newProfile);
        setShowOnboarding(true);
        await saveCachedProfile(newProfile);
      }

      // 6. Fetch remote active session if local wasn't set
      const { data: remoteActive } = await supabase
        .from('active_sessions')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      if (remoteActive && !localActive) {
        const active: ActiveSession = {
          user_id: remoteActive.user_id,
          session_id: remoteActive.session_id,
          mode: remoteActive.mode,
          started_at: remoteActive.started_at,
        };
        setActiveSession(active);
        await setLocalActiveSession(active);
      } else if (localActive && !remoteActive) {
        await supabase.from('active_sessions').upsert(localActive);
      }

      // 7. Fetch 4-month study sessions
      const { data: sessData } = await supabase
        .from('study_sessions')
        .select('*')
        .eq('user_id', userId)
        .order('started_at', { ascending: false });

      if (sessData) {
        setSessions(sessData as StudySession[]);
        await saveCachedSessions(userId, sessData as StudySession[]);
      }
    },
    [syncPendingSessions]
  );

  useEffect(() => {
    if (authSession) {
      loadUserData(authSession);
    }
  }, [authSession, loadUserData]);

  // Re-sync when coming back online
  useEffect(() => {
    if (isOnline && authSession) {
      syncPendingSessions(authSession.user.id).then(() => {
        loadUserData(authSession);
      });
    }
  }, [isOnline, authSession, syncPendingSessions, loadUserData]);

  // Start a study session
  const handleStartSession = async (mode: StudyMode) => {
    if (!authSession || activeSession) return;
    const newActive: ActiveSession = {
      user_id: authSession.user.id,
      session_id: crypto.randomUUID(),
      mode,
      started_at: new Date().toISOString(),
    };
    setActiveSession(newActive);
    await setLocalActiveSession(newActive);

    if (navigator.onLine) {
      await supabase.from('active_sessions').upsert(newActive);
    }
  };

  // Stop & Save study session
  const handleStopAndSave = async () => {
    if (!authSession || !activeSession) return;
    const endedAt = new Date();
    const startMs = new Date(activeSession.started_at).getTime();
    const durationSeconds = Math.max(1, Math.floor((endedAt.getTime() - startMs) / 1000));

    const completed: StudySession = {
      id: activeSession.session_id,
      user_id: authSession.user.id,
      mode: activeSession.mode,
      started_at: activeSession.started_at,
      ended_at: endedAt.toISOString(),
      duration_seconds: durationSeconds,
      study_date: getDhakaDateString(new Date(activeSession.started_at)),
    };

    // Clear active session locally first
    setActiveSession(null);
    await clearLocalActiveSession(authSession.user.id);

    // Update UI immediately
    setSessions((prev) => [completed, ...prev]);

    if (navigator.onLine) {
      await supabase.from('active_sessions').delete().eq('user_id', authSession.user.id);
      const { error } = await supabase
        .from('study_sessions')
        .upsert(completed, { onConflict: 'id', ignoreDuplicates: true });
      if (error) {
        await addPendingSession(completed);
        setPendingCount((c) => c + 1);
      } else {
        await saveCachedSessions(authSession.user.id, [completed, ...sessions]);
      }
    } else {
      await addPendingSession(completed);
      setPendingCount((c) => c + 1);
    }
  };

  const handleCompleteOnboarding = async () => {
    setShowOnboarding(false);
    if (!profile) return;
    const updated = { ...profile, onboarding_completed: true };
    setProfile(updated);
    await saveCachedProfile(updated);
    if (navigator.onLine) {
      await supabase
        .from('profiles')
        .update({ onboarding_completed: true, updated_at: new Date().toISOString() })
        .eq('id', profile.id);
    }
  };

  const handleUpdateProfile = async (updates: Partial<Profile>) => {
    if (!profile) return;
    const updated = { ...profile, ...updates, updated_at: new Date().toISOString() };
    setProfile(updated);
    await saveCachedProfile(updated);
    if (navigator.onLine) {
      await supabase.from('profiles').update(updates).eq('id', profile.id);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#0b0e11] bg-grid-pattern flex flex-col items-center justify-center">
        <FoxMascot state="sleeping" size={120} />
        <p className="text-xs text-lime-400 font-semibold tracking-widest uppercase mt-4 animate-pulse">
          HC Smart Study Tracker
        </p>
      </div>
    );
  }

  if (!authSession) {
    return <AuthScreen />;
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-[#0b0e11] bg-grid-pattern flex flex-col items-center justify-center">
        <FoxMascot state="reading" size={120} />
        <p className="text-sm text-slate-300 mt-3">তোমার প্রোফাইল লোড হচ্ছে...</p>
      </div>
    );
  }

  if (showOnboarding) {
    return <Onboarding onComplete={handleCompleteOnboarding} />;
  }

  return (
    <div className="min-h-screen bg-[#0b0e11] bg-grid-pattern text-white relative">
      {activeTab === 'home' && (
        <Dashboard
          profile={profile}
          sessions={sessions}
          activeSession={activeSession}
          isOnline={isOnline}
          pendingCount={pendingCount}
          onStartStudy={() => setActiveTab('study')}
        />
      )}

      {activeTab === 'study' && (
        <StudyTimer
          activeSession={activeSession}
          onStartSession={handleStartSession}
          onStopAndSave={handleStopAndSave}
        />
      )}

      {activeTab === 'progress' && <ProgressView sessions={sessions} />}

      {activeTab === 'ranking' && <RankingView currentUserId={authSession.user.id} profile={profile} />}

      {activeTab === 'profile' && (
        <ProfileView
          profile={profile}
          sessions={sessions}
          email={authSession.user.email || ''}
          onUpdateProfile={handleUpdateProfile}
          onRevisitOnboarding={() => setShowOnboarding(true)}
          onLogout={handleLogout}
        />
      )}

      <BottomNav
        activeTab={activeTab}
        onChange={setActiveTab}
        hasActiveSession={!!activeSession}
      />
    </div>
  );
}

export default App;
