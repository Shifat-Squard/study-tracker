import { openDB, type IDBPDatabase } from 'idb';
import type { ActiveSession, Profile, StudySession } from '../types/study';

const DB_NAME = 'hc-study-tracker-db';
const DB_VERSION = 1;

interface StudyDB {
  active_sessions: {
    key: string; // user_id
    value: ActiveSession;
  };
  pending_sessions: {
    key: string; // session id
    value: StudySession;
    indexes: { 'by-user': string };
  };
  cached_sessions: {
    key: string; // session id
    value: StudySession;
    indexes: { 'by-user': string };
  };
  cached_profiles: {
    key: string; // user_id
    value: Profile;
  };
}

let dbPromise: Promise<IDBPDatabase<StudyDB>> | null = null;

function getDB() {
  if (!dbPromise) {
    dbPromise = openDB<StudyDB>(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('active_sessions')) {
          db.createObjectStore('active_sessions', { keyPath: 'user_id' });
        }
        if (!db.objectStoreNames.contains('pending_sessions')) {
          const store = db.createObjectStore('pending_sessions', { keyPath: 'id' });
          store.createIndex('by-user', 'user_id');
        }
        if (!db.objectStoreNames.contains('cached_sessions')) {
          const store = db.createObjectStore('cached_sessions', { keyPath: 'id' });
          store.createIndex('by-user', 'user_id');
        }
        if (!db.objectStoreNames.contains('cached_profiles')) {
          db.createObjectStore('cached_profiles', { keyPath: 'id' });
        }
      },
    });
  }
  return dbPromise;
}

export async function getLocalActiveSession(userId: string): Promise<ActiveSession | undefined> {
  const db = await getDB();
  return db.get('active_sessions', userId);
}

export async function setLocalActiveSession(session: ActiveSession): Promise<void> {
  const db = await getDB();
  await db.put('active_sessions', session);
}

export async function clearLocalActiveSession(userId: string): Promise<void> {
  const db = await getDB();
  await db.delete('active_sessions', userId);
}

export async function addPendingSession(session: StudySession): Promise<void> {
  const db = await getDB();
  await db.put('pending_sessions', session);
  await db.put('cached_sessions', session);
}

export async function getPendingSessions(userId: string): Promise<StudySession[]> {
  const db = await getDB();
  return db.getAllFromIndex('pending_sessions', 'by-user', userId);
}

export async function removePendingSession(sessionId: string): Promise<void> {
  const db = await getDB();
  await db.delete('pending_sessions', sessionId);
}

export async function saveCachedSessions(userId: string, sessions: StudySession[]): Promise<void> {
  const db = await getDB();
  const tx = db.transaction('cached_sessions', 'readwrite');
  const index = tx.store.index('by-user');
  let cursor = await index.openCursor(userId);
  while (cursor) {
    await cursor.delete();
    cursor = await cursor.continue();
  }
  for (const s of sessions) {
    await tx.store.put(s);
  }
  await tx.done;
}

export async function getCachedSessions(userId: string): Promise<StudySession[]> {
  const db = await getDB();
  return db.getAllFromIndex('cached_sessions', 'by-user', userId);
}

export async function saveCachedProfile(profile: Profile): Promise<void> {
  const db = await getDB();
  await db.put('cached_profiles', profile);
}

export async function getCachedProfile(userId: string): Promise<Profile | undefined> {
  const db = await getDB();
  return db.get('cached_profiles', userId);
}
