import type { StudySession } from '../types/study';
import { getDhakaDateString } from './time';

export interface FoxLevel {
  level: number;
  title: string;
  minHours: number;
  accessory: string;
  color: string;
}

export const FOX_LEVELS: FoxLevel[] = [
  { level: 1, title: 'নবীন শিয়াল', minHours: 0, accessory: 'ক্লাসিক লুক', color: 'text-orange-400' },
  { level: 2, title: 'পাঠক শিয়াল', minHours: 5, accessory: 'চশমা আনলকড', color: 'text-sky-400' },
  { level: 3, title: 'মনোযোগী শিয়াল', minHours: 20, accessory: 'নিয়ন হেডব্যান্ড', color: 'text-lime-400' },
  { level: 4, title: 'জ্ঞানী শিয়াল', minHours: 50, accessory: 'স্কলার ক্যাপ', color: 'text-purple-400' },
  { level: 5, title: 'মাস্টার শিয়াল', minHours: 100, accessory: 'গোল্ডেন ক্রাউন', color: 'text-amber-400' },
];

export function getFoxLevel(totalSeconds: number): {
  current: FoxLevel;
  next: FoxLevel | null;
  progressPct: number;
} {
  const hours = totalSeconds / 3600;
  let current = FOX_LEVELS[0];
  for (const lvl of FOX_LEVELS) {
    if (hours >= lvl.minHours) current = lvl;
  }
  const next = FOX_LEVELS.find((l) => l.level === current.level + 1) ?? null;
  if (!next) {
    return { current, next: null, progressPct: 100 };
  }
  const span = next.minHours - current.minHours;
  const pct = Math.min(100, Math.max(0, Math.round(((hours - current.minHours) / span) * 100)));
  return { current, next, progressPct: pct };
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
}

export function computePersonalStats(sessions: StudySession[]) {
  let totalSeconds = 0;
  const byDate = new Map<string, number>();

  for (const s of sessions) {
    totalSeconds += s.duration_seconds;
    byDate.set(s.study_date, (byDate.get(s.study_date) ?? 0) + s.duration_seconds);
  }

  let bestDaySeconds = 0;
  let bestDayDate: string | null = null;
  for (const [date, secs] of byDate.entries()) {
    if (secs > bestDaySeconds) {
      bestDaySeconds = secs;
      bestDayDate = date;
    }
  }

  // Current streak (Asia/Dhaka)
  const today = new Date();
  let currentStreak = 0;
  for (let i = 0; i < 120; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    const dateStr = getDhakaDateString(d);
    if ((byDate.get(dateStr) ?? 0) > 0) {
      currentStreak++;
    } else if (i === 0) {
      // Allow today to have 0 yet if yesterday had a session
      continue;
    } else {
      break;
    }
  }

  // Weekly seconds (last 7 days)
  let weeklySeconds = 0;
  for (let i = 0; i < 7; i++) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    weeklySeconds += byDate.get(getDhakaDateString(d)) ?? 0;
  }

  return {
    totalSeconds,
    bestDaySeconds,
    bestDayDate,
    currentStreak,
    weeklySeconds,
  };
}

export function computeAchievements(sessions: StudySession[]): Achievement[] {
  const stats = computePersonalStats(sessions);
  const totalHours = stats.totalSeconds / 3600;
  const focusCount = sessions.filter((s) => s.mode === 'focus').length;
  const youtubeCount = sessions.filter((s) => s.mode === 'youtube').length;

  return [
    {
      id: 'first_session',
      title: 'প্রথম পদক্ষেপ',
      description: '১টি স্টাডি সেশন সম্পন্ন করো',
      icon: '🌱',
      unlocked: sessions.length >= 1,
    },
    {
      id: 'streak_3',
      title: '৩ দিনের ধারাবাহিকতা',
      description: 'টানা ৩ দিন পড়াশোনা করো',
      icon: '🔥',
      unlocked: stats.currentStreak >= 3,
    },
    {
      id: 'streak_7',
      title: 'সাপ্তাহিক যোদ্ধা',
      description: 'টানা ৭ দিন পড়াশোনা করো',
      icon: '⚡',
      unlocked: stats.currentStreak >= 7,
    },
    {
      id: 'hours_10',
      title: '১০ ঘণ্টা ক্লাব',
      description: 'মোট ১০ ঘণ্টা পড়াশোনা সম্পন্ন করো',
      icon: '📚',
      unlocked: totalHours >= 10,
    },
    {
      id: 'hours_50',
      title: '৫০ ঘণ্টা মাস্টার',
      description: 'মোট ৫০ ঘণ্টা পড়াশোনা সম্পন্ন করো',
      icon: '👑',
      unlocked: totalHours >= 50,
    },
    {
      id: 'focus_20',
      title: 'ফোকাস মাস্টার',
      description: 'Focus Mode-এ ২০টি সেশন সম্পন্ন করো',
      icon: '🎯',
      unlocked: focusCount >= 20,
    },
    {
      id: 'youtube_10',
      title: 'লেকচার প্রো',
      description: 'YouTube Study-তে ১০টি সেশন সম্পন্ন করো',
      icon: '▶️',
      unlocked: youtubeCount >= 10,
    },
  ];
}
