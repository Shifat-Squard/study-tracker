import React, { useState } from 'react';
import { supabase } from '../lib/supabase';
import { FoxMascot } from './FoxMascot';
import { Lock, Mail, User, School, GraduationCap, ArrowLeft, Loader2 } from 'lucide-react';

type AuthMode = 'login' | 'signup' | 'forgot';

const SSC_BATCHES = ['SSC 26', 'SSC 27', 'SSC 28', 'SSC 29'];

export const AuthScreen: React.FC = () => {
  const [mode, setMode] = useState<AuthMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [studentName, setStudentName] = useState('');
  const [sscBatch, setSscBatch] = useState('SSC 27');
  const [schoolName, setSchoolName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);

    try {
      if (mode === 'login') {
        const { error: signInErr } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password,
        });
        if (signInErr) throw signInErr;
      } else if (mode === 'signup') {
        if (!studentName.trim()) {
          throw new Error('তোমার নাম লিখো');
        }
        const { data, error: signUpErr } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            data: {
              student_name: studentName.trim(),
              ssc_batch: sscBatch,
              school_name: schoolName.trim() || null,
            },
          },
        });
        if (signUpErr) throw signUpErr;

        if (data.user && data.session) {
          await supabase.from('profiles').upsert({
            id: data.user.id,
            student_name: studentName.trim(),
            ssc_batch: sscBatch,
            school_name: schoolName.trim() || null,
            avatar_id: 'fox-classic',
            onboarding_completed: false,
          });
        } else if (data.user && !data.session) {
          setMessage('তোমার ইমেইলে ভেরিফিকেশন লিংক পাঠানো হয়েছে। ইমেইল চেক করো!');
        }
      } else if (mode === 'forgot') {
        const { error: resetErr } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: window.location.origin,
        });
        if (resetErr) throw resetErr;
        setMessage('পাসওয়ার্ড রিসেট লিংক তোমার ইমেইলে পাঠানো হয়েছে।');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'কিছু একটা সমস্যা হয়েছে।';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b0e11] bg-grid-pattern relative flex flex-col justify-center px-5 py-8 overflow-hidden">
      {/* Ambient lighting */}
      <div className="pointer-events-none absolute -top-24 right-0 w-72 h-72 rounded-full bg-lime-400/10 blur-3xl" />
      <div className="pointer-events-none absolute bottom-0 -left-24 w-72 h-72 rounded-full bg-purple-500/10 blur-3xl" />

      <div className="max-w-sm w-full mx-auto z-10 animate-fade-up">
        <div className="flex flex-col items-center text-center mb-6">
          <FoxMascot state={mode === 'signup' ? 'happy' : 'reading'} size={96} className="mb-2" />
          <span className="text-[11px] font-bold tracking-[0.2em] uppercase text-lime-400 mb-1">
            HC SMART STUDY TRACKER
          </span>
          <h1 className="text-2xl font-bold text-white">
            {mode === 'login' && 'স্বাগতম! লগইন করো'}
            {mode === 'signup' && 'নতুন অ্যাকাউন্ট তৈরি করো'}
            {mode === 'forgot' && 'পাসওয়ার্ড রিকভারি'}
          </h1>
        </div>

        <form onSubmit={handleSubmit} className="glass-card rounded-3xl p-5 space-y-4">
          {mode === 'forgot' && (
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
                setMessage(null);
              }}
              className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-white"
            >
              <ArrowLeft className="w-4 h-4" />
              লগইনে ফিরে যাও
            </button>
          )}

          {mode === 'signup' && (
            <>
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  তোমার নাম *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="যেমন: রাফি আহমেদ"
                    className="w-full bg-slate-900/80 border border-white/10 rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-lime-400/60"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    SSC ব্যাচ *
                  </label>
                  <div className="relative">
                    <GraduationCap className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <select
                      value={sscBatch}
                      onChange={(e) => setSscBatch(e.target.value)}
                      className="w-full bg-slate-900/80 border border-white/10 rounded-xl pl-9 pr-2 py-2.5 text-sm text-white focus:outline-none focus:border-lime-400/60"
                    >
                      {SSC_BATCHES.map((b) => (
                        <option key={b} value={b}>
                          {b}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1.5">
                    স্কুল (ঐচ্ছিক)
                  </label>
                  <div className="relative">
                    <School className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={schoolName}
                      onChange={(e) => setSchoolName(e.target.value)}
                      placeholder="স্কুলের নাম"
                      className="w-full bg-slate-900/80 border border-white/10 rounded-xl pl-9 pr-2.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-lime-400/60"
                    />
                  </div>
                </div>
              </div>
            </>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">ইমেইল</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="student@example.com"
                className="w-full bg-slate-900/80 border border-white/10 rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-lime-400/60"
              />
            </div>
          </div>

          {mode !== 'forgot' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">পাসওয়ার্ড</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="কমপক্ষে ৬ অক্ষর"
                  className="w-full bg-slate-900/80 border border-white/10 rounded-xl pl-10 pr-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-lime-400/60"
                />
              </div>
            </div>
          )}

          {error && (
            <div className="text-xs text-rose-300 bg-rose-500/10 border border-rose-500/25 rounded-xl p-3">
              {error}
            </div>
          )}

          {message && (
            <div className="text-xs text-lime-300 bg-lime-500/10 border border-lime-500/25 rounded-xl p-3">
              {message}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-lime-400 hover:bg-lime-300 active:scale-[0.98] disabled:opacity-60 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 transition shadow-[0_0_20px_rgba(163,230,53,0.3)]"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            {mode === 'login' && 'লগইন করো'}
            {mode === 'signup' && 'অ্যাকাউন্ট তৈরি করো'}
            {mode === 'forgot' && 'রিকভারি লিংক পাঠাও'}
          </button>

          {mode === 'login' && (
            <div className="flex items-center justify-between text-xs pt-1">
              <button
                type="button"
                onClick={() => {
                  setMode('forgot');
                  setError(null);
                  setMessage(null);
                }}
                className="text-slate-400 hover:text-lime-400 transition"
              >
                পাসওয়ার্ড ভুলে গেছো?
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('signup');
                  setError(null);
                  setMessage(null);
                }}
                className="text-lime-400 font-semibold hover:underline"
              >
                নতুন অ্যাকাউন্ট
              </button>
            </div>
          )}

          {mode === 'signup' && (
            <div className="text-center text-xs pt-1">
              <span className="text-slate-400">আগেই অ্যাকাউন্ট আছে? </span>
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError(null);
                  setMessage(null);
                }}
                className="text-lime-400 font-semibold hover:underline"
              >
                লগইন করো
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
