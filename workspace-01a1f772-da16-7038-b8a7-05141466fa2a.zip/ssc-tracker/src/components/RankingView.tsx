import React, { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { formatHM, getDhakaDateString } from '../lib/time';
import type { LeaderboardEntry, LeaderboardPeriod, Profile } from '../types/study';
import { FoxAvatar } from './FoxMascot';
import { RefreshCw, Clock, Crown, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface RankingViewProps {
  currentUserId: string;
  profile: Profile;
}

const PERIOD_TABS: { id: LeaderboardPeriod; label: string }[] = [
  { id: 'daily', label: 'দৈনিক' },
  { id: 'weekly', label: 'সাপ্তাহিক' },
  { id: 'monthly', label: 'মাসিক' },
  { id: 'batch', label: 'ব্যাচ' },
];

export const RankingView: React.FC<RankingViewProps> = ({ currentUserId, profile }) => {
  const [period, setPeriod] = useState<LeaderboardPeriod>('daily');
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [weeklyChampion, setWeeklyChampion] = useState<LeaderboardEntry | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchLeaderboard = useCallback(async () => {
    setLoading(true);
    try {
      const today = getDhakaDateString();
      const { data, error } = await supabase.rpc('get_leaderboard', {
        period_type: period,
        target_date: today,
        batch_filter: period === 'batch' ? profile.ssc_batch : null,
      });
      if (!error && data) {
        setEntries(data as LeaderboardEntry[]);
      }

      // Also fetch weekly champion
      const { data: champData } = await supabase.rpc('get_leaderboard', {
        period_type: 'weekly',
        target_date: today,
        batch_filter: null,
      });
      if (champData && champData.length > 0) {
        setWeeklyChampion(champData[0] as LeaderboardEntry);
      } else {
        setWeeklyChampion(null);
      }
    } finally {
      setLoading(false);
    }
  }, [period, profile.ssc_batch]);

  useEffect(() => {
    fetchLeaderboard();
  }, [fetchLeaderboard]);

  const renderRankDelta = (rank: number, prevRank: number | null) => {
    if (prevRank === null || prevRank === undefined) {
      return <span className="text-[10px] font-bold text-sky-400">NEW</span>;
    }
    const diff = Number(prevRank) - Number(rank);
    if (diff > 0) {
      return (
        <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-lime-400">
          <TrendingUp className="w-3 h-3" />+{diff}
        </span>
      );
    }
    if (diff < 0) {
      return (
        <span className="inline-flex items-center gap-0.5 text-[10px] font-bold text-rose-400">
          <TrendingDown className="w-3 h-3" />{diff}
        </span>
      );
    }
    return <Minus className="w-3 h-3 text-slate-500" />;
  };

  const top3 = entries.slice(0, 3);
  const podiumOrder = [top3[1], top3[0], top3[2]].filter(Boolean) as LeaderboardEntry[];

  return (
    <div className="pb-28 pt-5 px-4 max-w-md mx-auto space-y-4 animate-fade-up">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-lime-400 block">
            ফেয়ার স্টাডি লিডারবোর্ড
          </span>
          <h1 className="text-2xl font-bold text-white">র‍্যাংকিং</h1>
        </div>
        <button
          onClick={fetchLeaderboard}
          disabled={loading}
          aria-label="Refresh ranking"
          className="w-10 h-10 rounded-2xl glass-card flex items-center justify-center text-lime-400 hover:bg-white/10 transition disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* Weekly Champion Banner */}
      {weeklyChampion && (
        <div className="glass-card rounded-2xl p-3.5 border-amber-400/35 bg-gradient-to-r from-amber-500/10 via-transparent to-lime-500/5 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-amber-400/15 border border-amber-400/30 flex items-center justify-center shrink-0">
              <Crown className="w-5 h-5 text-amber-400" />
            </div>
            <div className="min-w-0">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 block">
                সাপ্তাহিক চ্যাম্পিয়ন
              </span>
              <p className="text-sm font-bold text-white truncate">
                {weeklyChampion.student_name} · {weeklyChampion.ssc_batch}
              </p>
            </div>
          </div>
          <span className="font-mono-timer text-xs font-bold text-amber-300 bg-amber-400/10 px-2.5 py-1 rounded-lg shrink-0">
            {formatHM(Number(weeklyChampion.total_seconds))}
          </span>
        </div>
      )}

      {/* Period Tabs */}
      <div className="glass-card-strong rounded-2xl p-1 grid grid-cols-4 gap-1">
        {PERIOD_TABS.map((t) => (
          <button
            key={t.id}
            onClick={() => setPeriod(t.id)}
            className={`py-2 rounded-xl text-xs font-bold transition ${
              period === t.id
                ? 'bg-lime-400 text-slate-950 shadow-[0_0_14px_rgba(163,230,53,0.35)]'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {profile.ranking_opt_in === false && (
        <div className="text-xs bg-amber-500/10 border border-amber-500/25 text-amber-300 rounded-xl px-3.5 py-2.5">
          তুমি প্রোফাইল থেকে র‍্যাংকিংয়ে অংশগ্রহণ বন্ধ রেখেছো। র‍্যাংকিংয়ে আসতে প্রোফাইল থেকে চালু করো।
        </div>
      )}

      {loading && entries.length === 0 ? (
        <div className="glass-card rounded-2xl p-8 text-center text-slate-400 text-sm">
          র‍্যাংকিং লোড হচ্ছে...
        </div>
      ) : entries.length === 0 ? (
        <div className="glass-card rounded-2xl p-8 text-center text-slate-400 text-sm">
          এই সময়ে এখনো কোনো পড়াশোনা রেকর্ড হয়নি। প্রথম স্থান দখল করো! 🚀
        </div>
      ) : (
        <>
          {/* Top 3 Podium */}
          {top3.length > 0 && (
            <div className="grid grid-cols-3 gap-2 items-end pt-3 pb-1">
              {podiumOrder.map((entry) => {
                const r = Number(entry.rank);
                const isFirst = r === 1;
                const isSecond = r === 2;
                const heightClass = isFirst ? 'pt-5 pb-4' : isSecond ? 'pt-3 pb-3' : 'pt-2 pb-3';
                const borderClass = isFirst
                  ? 'border-amber-400/50 bg-amber-400/10 shadow-[0_0_24px_rgba(250,204,21,0.15)]'
                  : isSecond
                  ? 'border-slate-300/35 bg-slate-300/5'
                  : 'border-orange-400/35 bg-orange-400/5';

                return (
                  <div
                    key={entry.user_id}
                    className={`glass-card rounded-2xl px-2 ${heightClass} ${borderClass} flex flex-col items-center text-center animate-fade-up`}
                  >
                    <span className="text-lg mb-1">
                      {isFirst ? '🥇' : isSecond ? '🥈' : '🥉'}
                    </span>
                    <FoxAvatar avatarId={entry.avatar_id} size={isFirst ? 'md' : 'sm'} />
                    <p className="text-xs font-bold text-white truncate w-full mt-2">
                      {entry.student_name}
                    </p>
                    <p className="text-[10px] text-slate-400">{entry.ssc_batch}</p>
                    <span className="font-mono-timer text-[11px] font-bold text-lime-300 mt-1">
                      {formatHM(Number(entry.total_seconds))}
                    </span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Full List */}
          <div className="space-y-2">
            {entries.map((entry) => {
              const isMe = entry.user_id === currentUserId;
              return (
                <div
                  key={entry.user_id}
                  className={`glass-card rounded-2xl p-3 flex items-center justify-between transition ${
                    isMe ? 'border-lime-400/50 bg-lime-400/10' : ''
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 flex flex-col items-center shrink-0">
                      <span className="text-xs font-bold text-white">#{entry.rank}</span>
                      {renderRankDelta(entry.rank, entry.prev_rank)}
                    </div>
                    <FoxAvatar avatarId={entry.avatar_id} size="sm" />
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-white truncate">
                        {entry.student_name}{' '}
                        {isMe && <span className="text-lime-400 text-xs">(তুমি)</span>}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        {entry.ssc_batch} · Focus {formatHM(Number(entry.focus_seconds))} · YT{' '}
                        {formatHM(Number(entry.youtube_seconds))}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 bg-white/5 px-2.5 py-1.5 rounded-xl shrink-0">
                    <Clock className="w-3 h-3 text-lime-400" />
                    <span className="font-mono-timer text-xs font-bold text-white">
                      {formatHM(Number(entry.total_seconds))}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
};
