import React from 'react';
import type { ActiveSession, Profile, StudySession } from '../types/study';
import { formatHM, getDhakaDateString } from '../lib/time';
import { FoxAvatar, FoxMascot } from './FoxMascot';
import { Play, Target, PlayCircle, Wifi, WifiOff, Clock, CheckCircle2 } from 'lucide-react';

interface DashboardProps {
  profile: Profile;
  sessions: StudySession[];
  activeSession: ActiveSession | null;
  isOnline: boolean;
  pendingCount: number;
  onStartStudy: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  profile,
  sessions,
  activeSession,
  isOnline,
  pendingCount,
  onStartStudy,
}) => {
  const today = getDhakaDateString();
  const todaySessions = sessions.filter((s) => s.study_date === today);

  const selfStudySeconds = todaySessions
    .filter((s) => s.mode === 'focus')
    .reduce((acc, s) => acc + s.duration_seconds, 0);

  const youtubeStudySeconds = todaySessions
    .filter((s) => s.mode === 'youtube')
    .reduce((acc, s) => acc + s.duration_seconds, 0);

  const totalTodaySeconds = selfStudySeconds + youtubeStudySeconds;

  return (
    <div className="pb-28 pt-4 px-4 max-w-md mx-auto space-y-5 animate-fade-up">
      {/* Header */}
      <header className="flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-lime-400 block">
            HC SMART STUDY TRACKER
          </span>
          <div className="flex items-center gap-2 mt-0.5">
            <h1 className="text-lg font-bold text-white truncate max-w-[180px]">
              {profile.student_name}
            </h1>
            <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-lime-400/15 text-lime-300 border border-lime-400/25">
              {profile.ssc_batch}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <div
            title={isOnline ? 'অনলাইন' : 'অফলাইন'}
            className={`w-8 h-8 rounded-full flex items-center justify-center border ${
              isOnline
                ? 'bg-emerald-500/10 border-emerald-500/25 text-emerald-400'
                : 'bg-amber-500/10 border-amber-500/25 text-amber-400'
            }`}
          >
            {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
          </div>
          <FoxAvatar avatarId={profile.avatar_id} size="md" />
        </div>
      </header>

      {pendingCount > 0 && (
        <div className="text-xs bg-amber-500/10 border border-amber-500/25 text-amber-300 rounded-xl px-3.5 py-2 flex items-center justify-between">
          <span>{pendingCount}টি সেশন অফলাইনে সেভ আছে — ইন্টারনেট পেলে সিঙ্ক হবে।</span>
        </div>
      )}

      {/* A. Welcome Section */}
      <section className="glass-card rounded-3xl p-5 relative overflow-hidden">
        <div className="pointer-events-none absolute -right-10 -top-10 w-36 h-36 rounded-full bg-lime-400/10 blur-2xl" />
        <p className="text-xs font-medium text-lime-400 mb-1">শুভকামনা, {profile.student_name}!</p>
        <h2 className="text-xl font-bold text-white leading-snug">
          আজকের পড়াশোনা শুরু করেছো?
        </h2>
        <div className="mt-4 flex items-center gap-4 text-xs text-slate-300">
          <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-xl border border-white/5">
            <Clock className="w-3.5 h-3.5 text-lime-400" />
            <span>মোট: <strong className="text-white">{formatHM(totalTodaySeconds)}</strong></span>
          </div>
          <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-xl border border-white/5">
            <CheckCircle2 className="w-3.5 h-3.5 text-sky-400" />
            <span>সেশন: <strong className="text-white">{todaySessions.length}টি</strong></span>
          </div>
        </div>
      </section>

      {/* B. Today's Study Statistics */}
      <section className="grid grid-cols-2 gap-3">
        <div className="glass-card rounded-2xl p-4 border-lime-400/20">
          <div className="flex items-center gap-2 mb-2.5">
            <div className="w-8 h-8 rounded-xl bg-lime-400/15 flex items-center justify-center">
              <Target className="w-4 h-4 text-lime-400" />
            </div>
            <span className="text-xs font-medium text-slate-300">Self Study</span>
          </div>
          <p className="text-xl font-bold text-white font-mono-timer">
            {formatHM(selfStudySeconds)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">নিজের পড়াশোনা</p>
        </div>

        <div className="glass-card rounded-2xl p-4 border-sky-400/20">
          <div className="flex items-center gap-2 mb-2.5">
            <div className="w-8 h-8 rounded-xl bg-sky-400/15 flex items-center justify-center">
              <PlayCircle className="w-4 h-4 text-sky-400" />
            </div>
            <span className="text-xs font-medium text-slate-300">YouTube Study</span>
          </div>
          <p className="text-xl font-bold text-white font-mono-timer">
            {formatHM(youtubeStudySeconds)}
          </p>
          <p className="text-[11px] text-slate-400 mt-0.5">ক্লাস ও লেকচার</p>
        </div>
      </section>

      {/* C. Study Companion */}
      <section className="glass-card rounded-3xl p-4 flex items-center gap-4">
        <FoxMascot state={activeSession ? 'active' : 'sleeping'} size={86} className="shrink-0" />
        <div>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-orange-400">
            {activeSession ? 'সেশন চলছে...' : 'তোমার স্টাডি সঙ্গী'}
          </span>
          <p className="text-sm font-medium text-white mt-0.5 leading-relaxed">
            {activeSession
              ? 'দারুণ! মনোযোগ দিয়ে পড়তে থাকো। আমি সাথেই আছি! 🦊'
              : 'প্রতিদিন একটু একটু করে এগিয়ে যাও! 🦊'}
          </p>
        </div>
      </section>

      {/* D. Start Studying CTA */}
      <section className="flex flex-col items-center justify-center pt-2">
        <button
          onClick={onStartStudy}
          aria-label="Start Studying"
          className="w-24 h-24 rounded-full bg-gradient-to-br from-lime-300 via-lime-400 to-emerald-400 hover:brightness-110 active:scale-95 text-slate-950 flex flex-col items-center justify-center transition-all duration-200 animate-pulse-glow cursor-pointer"
        >
          <Play className="w-9 h-9 fill-slate-950 ml-1" />
        </button>
        <span className="mt-3 text-sm font-semibold text-slate-200">
          {activeSession ? 'চলমান সেশনে ফিরে যাও' : 'পড়াশোনা শুরু করো'}
        </span>
      </section>
    </div>
  );
};
