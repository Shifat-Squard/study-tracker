import React, { useState } from 'react';
import { FoxMascot } from './FoxMascot';
import { ArrowRight, Play, Target } from 'lucide-react';

interface OnboardingProps {
  onComplete: () => void;
}

export const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(0);

  return (
    <div className="min-h-screen bg-[#0b0e11] bg-grid-pattern relative flex flex-col justify-between p-6 overflow-hidden">
      {/* Ambient lighting */}
      <div className="pointer-events-none absolute -top-24 -left-24 w-72 h-72 rounded-full bg-lime-400/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -right-24 w-72 h-72 rounded-full bg-sky-500/10 blur-3xl" />

      {/* Top Skip */}
      <div className="flex justify-between items-center z-10 pt-2">
        <span className="text-xs font-semibold tracking-widest uppercase text-lime-400/90">
          HC Smart Study
        </span>
        <button
          onClick={onComplete}
          className="text-sm text-slate-400 hover:text-white px-3 py-1.5 rounded-full glass-card transition"
        >
          স্কিপ করো
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center text-center max-w-sm mx-auto w-full z-10 animate-fade-up" key={step}>
        {step === 0 && (
          <>
            <FoxMascot state="sleeping" size={180} className="mb-6" />
            <h1 className="text-3xl font-bold text-white mb-3 leading-snug">
              হেই! 👋 আমি তোমার শিয়াল 🦊
            </h1>
            <p className="text-slate-400 text-base leading-relaxed">
              তোমার SSC পরীক্ষার প্রস্তুতির প্রতিদিনের সঙ্গী। চলো একসাথে পড়াশোনাকে আরও সহজ ও নিয়মিত করি!
            </p>
          </>
        )}

        {step === 1 && (
          <>
            <FoxMascot state="reading" size={180} className="mb-6" />
            <h1 className="text-2xl font-bold text-white mb-3 leading-snug">
              প্রতিদিন একটু একটু করে এগিয়ে যাও
            </h1>
            <p className="text-slate-400 text-base leading-relaxed">
              প্রতিদিন নিয়মিত পড়াশোনা করলে তোমার প্রগ্রেস বাড়বে। তুমি কতক্ষণ পড়ছো, তার সব হিসাব আমি যত্ন করে রাখবো।
            </p>
          </>
        )}

        {step === 2 && (
          <>
            <div className="w-full space-y-3 mb-8">
              <div className="glass-card rounded-2xl p-4 flex items-center gap-4 text-left border-lime-400/25">
                <div className="w-12 h-12 rounded-xl bg-lime-400/15 border border-lime-400/30 flex items-center justify-center shrink-0">
                  <Target className="w-6 h-6 text-lime-400" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">🎯 Focus Mode</h3>
                  <p className="text-slate-400 text-sm">নিজের পড়াশোনা — বই পড়া, অংক করা বা নোট লেখা।</p>
                </div>
              </div>

              <div className="glass-card rounded-2xl p-4 flex items-center gap-4 text-left border-sky-400/25">
                <div className="w-12 h-12 rounded-xl bg-sky-400/15 border border-sky-400/30 flex items-center justify-center shrink-0">
                  <Play className="w-6 h-6 text-sky-400" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-base">▶️ YouTube Study Mode</h3>
                  <p className="text-slate-400 text-sm">YouTube ক্লাস বা লেকচার দেখা আলাদাভাবে ট্র্যাক করা।</p>
                </div>
              </div>
            </div>

            <h2 className="text-2xl font-bold text-white mb-2">
              দুইটি মোডে স্মার্ট ট্র্যাকিং
            </h2>
            <p className="text-slate-400 text-sm">
              তুমি প্রস্তুত? চলো আজকের পড়াশোনা শুরু করি!
            </p>
          </>
        )}
      </div>

      {/* Bottom Controls */}
      <div className="z-10 max-w-sm mx-auto w-full pb-4">
        {/* Dots */}
        <div className="flex justify-center gap-2 mb-6">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className={`h-2 rounded-full transition-all duration-300 ${
                step === i ? 'w-7 bg-lime-400' : 'w-2 bg-slate-700'
              }`}
            />
          ))}
        </div>

        {step < 2 ? (
          <button
            onClick={() => setStep(step + 1)}
            className="w-full py-4 rounded-2xl bg-lime-400 hover:bg-lime-300 active:scale-[0.98] text-slate-950 font-bold text-base flex items-center justify-center gap-2 transition shadow-[0_0_24px_rgba(163,230,53,0.35)]"
          >
            <span>পরের কথা</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        ) : (
          <button
            onClick={onComplete}
            className="w-full py-4 rounded-2xl bg-lime-400 hover:bg-lime-300 active:scale-[0.98] text-slate-950 font-bold text-base flex items-center justify-center gap-2 transition shadow-[0_0_24px_rgba(163,230,53,0.4)]"
          >
            <span>শুরু করি 🚀</span>
          </button>
        )}
      </div>
    </div>
  );
};
