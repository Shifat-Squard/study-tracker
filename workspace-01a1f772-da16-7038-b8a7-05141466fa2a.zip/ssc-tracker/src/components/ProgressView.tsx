import React, { useMemo, useState } from 'react';
import type { StudySession } from '../types/study';
import {
  formatDisplayDate,
  formatHM,
  formatHMS,
  formatTimeShort,
  getDhakaDateString,
} from '../lib/time';
import { Calendar, Target, PlayCircle, Clock, History } from 'lucide-react';

interface ProgressViewProps {
  sessions: StudySession[];
}

export const ProgressView: React.FC<ProgressViewProps> = ({ sessions }) => {
  const today = getDhakaDateString();
  const [selectedDate, setSelectedDate] = useState<string>(today);

  const stats = useMemo(() => {
    let todayTotal = 0;
    let totalAll = 0;
    let focusAll = 0;
    let youtubeAll = 0;

    for (const s of sessions) {
      totalAll += s.duration_seconds;
      if (s.mode === 'focus') focusAll += s.duration_seconds;
      else youtubeAll += s.duration_seconds;
      if (s.study_date === today) todayTotal += s.duration_seconds;
    }

    return { todayTotal, totalAll, focusAll, youtubeAll };
  }, [sessions, today]);

  // Last 7 days chart data
  const last7Days = useMemo(() => {
    const days: { date: string; label: string; focus: number; youtube: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = getDhakaDateString(d);
      const label = new Intl.DateTimeFormat('en-US', {
        weekday: 'short',
        timeZone: 'Asia/Dhaka',
      }).format(d);

      const daySessions = sessions.filter((s) => s.study_date === dateStr);
      const focus = daySessions
        .filter((s) => s.mode === 'focus')
        .reduce((a, b) => a + b.duration_seconds, 0);
      const youtube = daySessions
        .filter((s) => s.mode === 'youtube')
        .reduce((a, b) => a + b.duration_seconds, 0);

      days.push({ date: dateStr, label, focus, youtube });
    }
    return days;
  }, [sessions]);

  const maxDaySeconds = Math.max(
    60,
    ...last7Days.map((d) => d.focus + d.youtube)
  );

  // Unique study dates sorted descending
  const availableDates = useMemo(() => {
    const set = new Set(sessions.map((s) => s.study_date));
    return Array.from(set).sort((a, b) => (a < b ? 1 : -1));
  }, [sessions]);

  const selectedSessions = useMemo(
    () =>
      sessions
        .filter((s) => s.study_date === selectedDate)
        .sort((a, b) => (a.started_at < b.started_at ? 1 : -1)),
    [sessions, selectedDate]
  );

  return (
    <div className="pb-28 pt-5 px-4 max-w-md mx-auto space-y-5 animate-fade-up">
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-lime-400 block">
            ৪ মাসের স্টাডি হিস্ট্রি
          </span>
          <h1 className="text-2xl font-bold text-white">তোমার প্রগ্রেস</h1>
        </div>
        <div className="w-10 h-10 rounded-2xl glass-card flex items-center justify-center">
          <History className="w-5 h-5 text-lime-400" />
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="glass-card rounded-2xl p-4">
          <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
            <Clock className="w-3.5 h-3.5 text-lime-400" /> আজকের মোট
          </span>
          <p className="text-xl font-bold text-white font-mono-timer">
            {formatHM(stats.todayTotal)}
          </p>
        </div>

        <div className="glass-card rounded-2xl p-4">
          <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
            <History className="w-3.5 h-3.5 text-purple-400" /> ৪ মাসের মোট
          </span>
          <p className="text-xl font-bold text-white font-mono-timer">
            {formatHM(stats.totalAll)}
          </p>
        </div>

        <div className="glass-card rounded-2xl p-4">
          <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
            <Target className="w-3.5 h-3.5 text-lime-400" /> Self Study
          </span>
          <p className="text-lg font-bold text-lime-300 font-mono-timer">
            {formatHM(stats.focusAll)}
          </p>
        </div>

        <div className="glass-card rounded-2xl p-4">
          <span className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
            <PlayCircle className="w-3.5 h-3.5 text-sky-400" /> YouTube Study
          </span>
          <p className="text-lg font-bold text-sky-300 font-mono-timer">
            {formatHM(stats.youtubeAll)}
          </p>
        </div>
      </div>

      {/* 7-Day Bar Chart */}
      <div className="glass-card rounded-3xl p-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-white">গত ৭ দিনের পড়াশোনা</h2>
          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-lime-400" /> Focus
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-sky-400" /> YouTube
            </span>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2 items-end h-32 pt-2">
          {last7Days.map((day) => {
            const total = day.focus + day.youtube;
            const totalPct = Math.max(4, Math.round((total / maxDaySeconds) * 100));
            const focusPct = total > 0 ? Math.round((day.focus / total) * 100) : 0;
            const isSelected = day.date === selectedDate;

            return (
              <button
                key={day.date}
                onClick={() => setSelectedDate(day.date)}
                className="flex flex-col items-center gap-1.5 h-full justify-end group"
              >
                <div className="w-full max-w-[22px] h-24 bg-white/5 rounded-lg overflow-hidden flex flex-col justify-end p-0.5">
                  {total > 0 ? (
                    <div
                      style={{ height: `${totalPct}%` }}
                      className="w-full rounded-md overflow-hidden flex flex-col justify-end transition-all duration-300"
                    >
                      <div
                        style={{ height: `${100 - focusPct}%` }}
                        className="w-full bg-sky-400"
                      />
                      <div
                        style={{ height: `${focusPct}%` }}
                        className="w-full bg-lime-400"
                      />
                    </div>
                  ) : (
                    <div className="w-full h-1 bg-white/10 rounded-full" />
                  )}
                </div>
                <span
                  className={`text-[10px] font-medium ${
                    isSelected ? 'text-lime-400 font-bold' : 'text-slate-400'
                  }`}
                >
                  {day.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Date Selector & Sessions List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Calendar className="w-4 h-4 text-lime-400" />
            <span>{formatDisplayDate(selectedDate)}</span>
          </h2>
          <input
            type="date"
            value={selectedDate}
            max={today}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="bg-slate-900/90 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-lime-400/50"
          />
        </div>

        {/* Quick date pills */}
        {availableDates.length > 0 && (
          <div className="flex gap-2 overflow-x-auto pb-1">
            {availableDates.slice(0, 7).map((d) => (
              <button
                key={d}
                onClick={() => setSelectedDate(d)}
                className={`px-3 py-1 rounded-full text-xs whitespace-nowrap border transition ${
                  selectedDate === d
                    ? 'bg-lime-400/15 border-lime-400/40 text-lime-300 font-semibold'
                    : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                }`}
              >
                {d === today ? 'আজ' : d}
              </button>
            ))}
          </div>
        )}

        {selectedSessions.length === 0 ? (
          <div className="glass-card rounded-2xl p-6 text-center text-slate-400 text-sm">
            এই তারিখে কোনো পড়াশোনার সেশন রেকর্ড করা হয়নি।
          </div>
        ) : (
          <div className="space-y-2.5">
            {selectedSessions.map((s) => (
              <div
                key={s.id}
                className="glass-card rounded-2xl p-3.5 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      s.mode === 'focus'
                        ? 'bg-lime-400/15 text-lime-400'
                        : 'bg-sky-400/15 text-sky-400'
                    }`}
                  >
                    {s.mode === 'focus' ? (
                      <Target className="w-5 h-5" />
                    ) : (
                      <PlayCircle className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">
                      {s.mode === 'focus' ? 'Focus Mode' : 'YouTube Study'}
                    </p>
                    <p className="text-xs text-slate-400">
                      {formatTimeShort(s.started_at)} – {formatTimeShort(s.ended_at)}
                    </p>
                  </div>
                </div>
                <span className="font-mono-timer text-sm font-bold text-white bg-white/5 px-3 py-1.5 rounded-xl">
                  {formatHMS(s.duration_seconds)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
