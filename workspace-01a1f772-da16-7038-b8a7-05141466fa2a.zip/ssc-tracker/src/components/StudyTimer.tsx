import React, { useEffect, useState } from 'react';
import type { ActiveSession, FoxState, StudyMode } from '../types/study';
import { formatHMS } from '../lib/time';
import { FoxMascot } from './FoxMascot';
import { Play, Square, Target, PlayCircle, Sparkles } from 'lucide-react';

interface StudyTimerProps {
  activeSession: ActiveSession | null;
  onStartSession: (mode: StudyMode) => Promise<void>;
  onStopAndSave: () => Promise<void>;
}

export const StudyTimer: React.FC<StudyTimerProps> = ({
  activeSession,
  onStartSession,
  onStopAndSave,
}) => {
  const [selectedMode, setSelectedMode] = useState<StudyMode>(
    activeSession?.mode ?? 'focus'
  );
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);
  const [busy, setBusy] = useState(false);
  const [justCompleted, setJustCompleted] = useState(false);

  // Sync selectedMode when activeSession changes
  useEffect(() => {
    if (activeSession) {
      setSelectedMode(activeSession.mode);
    }
  }, [activeSession]);

  // Persistent timestamp-based elapsed time calculation
  useEffect(() => {
    if (!activeSession) {
      setElapsedSeconds(0);
      return;
    }

    const computeElapsed = () => {
      const startMs = new Date(activeSession.started_at).getTime();
      const diffSec = Math.max(0, Math.floor((Date.now() - startMs) / 1000));
      setElapsedSeconds(diffSec);
    };

    computeElapsed();
    const interval = window.setInterval(computeElapsed, 250);
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        computeElapsed();
      }
    };
    document.addEventListener('visibilitychange', onVisibility);

    return () => {
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [activeSession]);

  const handleStart = async () => {
    if (busy || activeSession) return;
    setBusy(true);
    setJustCompleted(false);
    try {
      await onStartSession(selectedMode);
    } finally {
      setBusy(false);
    }
  };

  const handleStop = async () => {
    if (busy || !activeSession) return;
    setBusy(true);
    try {
      await onStopAndSave();
      setJustCompleted(true);
      window.setTimeout(() => setJustCompleted(false), 3500);
    } finally {
      setBusy(false);
    }
  };

  const currentMode = activeSession ? activeSession.mode : selectedMode;

  let foxState: FoxState = 'reading';
  if (justCompleted) {
    foxState = 'happy';
  } else if (currentMode === 'youtube') {
    foxState = 'active';
  } else {
    foxState = activeSession ? 'reading' : 'sleeping';
  }

  return (
    <div className="min-h-screen relative flex flex-col justify-between pb-28 pt-5 px-4 overflow-hidden">
      {/* Illustrated Nature Background (Calm Blue Sky, Mountains, Forest, Green Landscape) */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0c1b2e] via-[#0f2438] to-[#0b191e]" />
        {/* Soft ambient glow */}
        <div
          className={`absolute top-12 left-1/2 -translate-x-1/2 w-80 h-80 rounded-full blur-3xl transition-colors duration-700 ${
            currentMode === 'focus' ? 'bg-lime-400/12' : 'bg-sky-400/15'
          }`}
        />
        {/* Illustrated SVG Mountains & Forest */}
        <svg
          viewBox="0 0 400 300"
          preserveAspectRatio="none"
          className="absolute bottom-0 left-0 w-full h-[52vh] opacity-80"
        >
          {/* Distant mountains */}
          <path
            d="M0 170 L85 95 L165 155 L255 80 L345 145 L400 110 L400 300 L0 300 Z"
            fill="#132a3e"
          />
          {/* Closer mountains */}
          <path
            d="M0 200 L65 140 L145 190 L225 130 L315 185 L400 145 L400 300 L0 300 Z"
            fill="#0f292e"
          />
          {/* Green rolling hills */}
          <path
            d="M0 225 Q100 195 200 220 T400 210 L400 300 L0 300 Z"
            fill="#133829"
          />
          <path
            d="M0 250 Q120 230 240 255 T400 245 L400 300 L0 300 Z"
            fill="#0d261c"
          />
          {/* Pine trees */}
          <polygon points="35,235 47,195 59,235" fill="#164e34" />
          <polygon points="62,240 72,208 82,240" fill="#14532d" />
          <polygon points="320,235 332,190 344,235" fill="#164e34" />
          <polygon points="348,242 358,210 368,242" fill="#14532d" />
        </svg>
      </div>

      {/* Top Mode Selector */}
      <div className="relative z-10 max-w-md mx-auto w-full">
        <div className="glass-card-strong rounded-2xl p-1.5 grid grid-cols-2 gap-1.5">
          <button
            type="button"
            disabled={!!activeSession}
            onClick={() => setSelectedMode('focus')}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition ${
              currentMode === 'focus'
                ? 'bg-lime-400 text-slate-950 shadow-[0_0_16px_rgba(163,230,53,0.35)]'
                : 'text-slate-300 hover:text-white disabled:opacity-40'
            }`}
          >
            <Target className="w-4 h-4" />
            <span>Focus Mode</span>
          </button>

          <button
            type="button"
            disabled={!!activeSession}
            onClick={() => setSelectedMode('youtube')}
            className={`py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition ${
              currentMode === 'youtube'
                ? 'bg-sky-400 text-slate-950 shadow-[0_0_16px_rgba(56,189,248,0.35)]'
                : 'text-slate-300 hover:text-white disabled:opacity-40'
            }`}
          >
            <PlayCircle className="w-4 h-4" />
            <span>YouTube Study</span>
          </button>
        </div>
        {activeSession && (
          <p className="text-center text-[11px] text-slate-400 mt-2">
            সেশন চলাকালীন মোড পরিবর্তন করা যাবে না
          </p>
        )}
      </div>

      {/* Center Fox & Digital Timer */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center text-center my-4">
        <FoxMascot state={foxState} size={160} className="mb-3" />

        {justCompleted ? (
          <div className="glass-card rounded-2xl px-5 py-3 mb-4 border-lime-400/40 animate-fade-up">
            <p className="text-lime-300 font-bold text-sm flex items-center gap-1.5">
              <Sparkles className="w-4 h-4" />
              দারুণ! সেশনটি সেভ করা হয়েছে 🎉
            </p>
          </div>
        ) : (
          <span
            className={`text-xs font-semibold px-3.5 py-1 rounded-full border mb-3 ${
              currentMode === 'focus'
                ? 'bg-lime-400/10 border-lime-400/30 text-lime-300'
                : 'bg-sky-400/10 border-sky-400/30 text-sky-300'
            }`}
          >
            {currentMode === 'focus' ? '🎯 Focus Mode — নিজের পড়াশোনা' : '▶️ YouTube Study Mode'}
          </span>
        )}

        {/* Large Digital Timer */}
        <div className="font-mono-timer text-5xl sm:text-6xl font-bold tracking-tight text-white drop-shadow-[0_4px_24px_rgba(0,0,0,0.6)]">
          {formatHMS(elapsedSeconds)}
        </div>

        <p className="text-xs text-slate-400 mt-2">
          {activeSession
            ? 'টাইমার ব্যাকগ্রাউন্ডেও সঠিকভাবে চলতে থাকবে'
            : 'শুরু করতে নিচের বাটনে ট্যাপ করো'}
        </p>
      </div>

      {/* Bottom Action Button */}
      <div className="relative z-10 max-w-md mx-auto w-full">
        {!activeSession ? (
          <button
            onClick={handleStart}
            disabled={busy}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-lime-400 via-lime-300 to-emerald-400 hover:brightness-110 active:scale-[0.97] disabled:opacity-60 text-slate-950 font-bold text-base flex items-center justify-center gap-2.5 transition-all duration-200 shadow-[0_0_28px_rgba(163,230,53,0.45)] cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            <span>পড়াশোনা শুরু করো</span>
          </button>
        ) : (
          <button
            onClick={handleStop}
            disabled={busy}
            className="w-full py-4 rounded-2xl bg-gradient-to-r from-rose-500 via-pink-500 to-red-500 hover:brightness-110 active:scale-[0.97] disabled:opacity-60 text-white font-bold text-base flex items-center justify-center gap-2.5 transition-all duration-200 shadow-[0_0_28px_rgba(244,63,94,0.45)] cursor-pointer"
          >
            <Square className="w-5 h-5 fill-white" />
            <span>থামাও ও সেভ করো</span>
          </button>
        )}
      </div>
    </div>
  );
};
