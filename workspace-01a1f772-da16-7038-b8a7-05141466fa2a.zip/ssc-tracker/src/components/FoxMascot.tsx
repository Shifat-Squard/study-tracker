import React from 'react';
import type { FoxState } from '../types/study';

interface FoxMascotProps {
  state: FoxState;
  size?: number;
  className?: string;
}

export const FoxMascot: React.FC<FoxMascotProps> = ({
  state,
  size = 140,
  className = '',
}) => {
  return (
    <div
      className={`relative inline-flex items-center justify-center select-none ${className}`}
      style={{ width: size, height: size }}
    >
      <svg
        viewBox="0 0 160 160"
        className="w-full h-full drop-shadow-[0_12px_24px_rgba(249,115,22,0.22)] animate-float-slow"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Ambient glow */}
        <circle cx="80" cy="86" r="54" fill="#f97316" fillOpacity="0.12" />

        {/* Tail */}
        <path
          d="M112 114 C138 112, 146 88, 128 78 C118 72, 110 86, 108 102 Z"
          fill="#ea580c"
        />
        <path
          d="M128 78 C138 82, 138 92, 130 96 C125 90, 124 84, 128 78 Z"
          fill="#fff7ed"
        />

        {/* Body */}
        <ellipse cx="80" cy="112" rx="34" ry="26" fill="#f97316" />
        <ellipse cx="80" cy="116" rx="20" ry="18" fill="#fff7ed" />

        {/* Ears */}
        <path d="M44 56 L54 24 L70 48 Z" fill="#ea580c" />
        <path d="M116 56 L106 24 L90 48 Z" fill="#ea580c" />
        <path d="M49 52 L55 31 L66 48 Z" fill="#fed7aa" />
        <path d="M111 52 L105 31 L94 48 Z" fill="#fed7aa" />

        {/* Head */}
        <ellipse cx="80" cy="68" rx="36" ry="30" fill="#fb923c" />
        {/* Cheeks */}
        <path
          d="M45 72 Q80 100 115 72 Q104 96 80 98 Q56 96 45 72 Z"
          fill="#fff7ed"
        />

        {/* Eyes & expressions by state */}
        {state === 'sleeping' && (
          <>
            <path
              d="M58 64 Q64 70 70 64"
              stroke="#1c1917"
              strokeWidth="3.2"
              strokeLinecap="round"
            />
            <path
              d="M90 64 Q96 70 102 64"
              stroke="#1c1917"
              strokeWidth="3.2"
              strokeLinecap="round"
            />
            {/* Zzz */}
            <text
              x="116"
              y="38"
              fill="#a3e635"
              fontSize="14"
              fontWeight="700"
              className="animate-pulse"
            >
              Z
            </text>
            <text
              x="128"
              y="26"
              fill="#a3e635"
              fontSize="11"
              fontWeight="700"
              opacity="0.7"
            >
              z
            </text>
          </>
        )}

        {(state === 'reading' || state === 'active') && (
          <>
            <circle cx="64" cy="63" r="4.8" fill="#1c1917" />
            <circle cx="96" cy="63" r="4.8" fill="#1c1917" />
            <circle cx="65.8" cy="61.2" r="1.7" fill="#ffffff" />
            <circle cx="97.8" cy="61.2" r="1.7" fill="#ffffff" />
          </>
        )}

        {state === 'happy' && (
          <>
            <path
              d="M58 65 Q64 57 70 65"
              stroke="#1c1917"
              strokeWidth="3.4"
              strokeLinecap="round"
            />
            <path
              d="M90 65 Q96 57 102 65"
              stroke="#1c1917"
              strokeWidth="3.4"
              strokeLinecap="round"
            />
            {/* Sparkles */}
            <path d="M26 42 L30 34 L34 42 L42 46 L34 50 L30 58 L26 50 L18 46 Z" fill="#a3e635" />
            <path d="M128 36 L131 30 L134 36 L140 39 L134 42 L131 48 L128 42 L122 39 Z" fill="#38bdf8" />
          </>
        )}

        {/* Nose */}
        <ellipse cx="80" cy="76" rx="5.5" ry="3.8" fill="#1c1917" />

        {/* Mouth */}
        {state === 'happy' ? (
          <path
            d="M73 82 Q80 90 87 82"
            stroke="#1c1917"
            strokeWidth="2.8"
            strokeLinecap="round"
          />
        ) : (
          <path
            d="M75 82 Q80 86 85 82"
            stroke="#1c1917"
            strokeWidth="2.4"
            strokeLinecap="round"
          />
        )}

        {/* Reading Book */}
        {state === 'reading' && (
          <g transform="translate(50, 108)">
            <path
              d="M0 6 Q15 0 30 6 L30 28 Q15 22 0 28 Z"
              fill="#e2e8f0"
              stroke="#475569"
              strokeWidth="1.5"
            />
            <path
              d="M30 6 Q45 0 60 6 L60 28 Q45 22 30 28 Z"
              fill="#f8fafc"
              stroke="#475569"
              strokeWidth="1.5"
            />
            <line x1="30" y1="6" x2="30" y2="28" stroke="#64748b" strokeWidth="1.5" />
          </g>
        )}

        {/* Active Laptop */}
        {state === 'active' && (
          <g transform="translate(46, 108)">
            <rect
              x="6"
              y="0"
              width="56"
              height="30"
              rx="4"
              fill="#1e293b"
              stroke="#a3e635"
              strokeWidth="1.8"
            />
            <rect x="11" y="4" width="46" height="21" rx="2" fill="#0f172a" />
            <polygon points="30,10 30,19 40,14.5" fill="#ef4444" />
            <path d="M0 30 L68 30 L62 36 L6 36 Z" fill="#475569" />
          </g>
        )}
      </svg>
    </div>
  );
};

export const AVATAR_OPTIONS = [
  { id: 'fox-classic', label: 'ক্লাসিক শিয়াল', bg: 'from-orange-500/20 to-amber-500/20', ring: 'border-orange-400/50' },
  { id: 'fox-lime', label: 'নিয়ন শিয়াল', bg: 'from-lime-500/20 to-emerald-500/20', ring: 'border-lime-400/50' },
  { id: 'fox-sky', label: 'আকাশী শিয়াল', bg: 'from-sky-500/20 to-blue-500/20', ring: 'border-sky-400/50' },
  { id: 'fox-purple', label: 'রাতের শিয়াল', bg: 'from-purple-500/20 to-fuchsia-500/20', ring: 'border-purple-400/50' },
];

export const FoxAvatar: React.FC<{
  avatarId?: string;
  size?: 'sm' | 'md' | 'lg';
  level?: number;
}> = ({ avatarId = 'fox-classic', size = 'md', level = 1 }) => {
  const option = AVATAR_OPTIONS.find((a) => a.id === avatarId) || AVATAR_OPTIONS[0];
  const dims =
    size === 'sm' ? 'w-9 h-9' : size === 'lg' ? 'w-16 h-16' : 'w-11 h-11';

  return (
    <div
      className={`${dims} rounded-2xl bg-gradient-to-br ${option.bg} border ${option.ring} flex items-center justify-center overflow-hidden shrink-0 relative`}
    >
      <svg viewBox="0 0 64 64" className="w-4/5 h-4/5">
        <path d="M12 24 L20 10 L28 22 Z" fill="#ea580c" />
        <path d="M52 24 L44 10 L36 22 Z" fill="#ea580c" />
        <ellipse cx="32" cy="36" rx="18" ry="15" fill="#fb923c" />
        <path d="M16 38 Q32 52 48 38 Q42 50 32 51 Q22 50 16 38 Z" fill="#fff7ed" />
        <circle cx="24" cy="33" r="2.4" fill="#1c1917" />
        <circle cx="40" cy="33" r="2.4" fill="#1c1917" />
        <ellipse cx="32" cy="40" rx="2.8" ry="2" fill="#1c1917" />
        {/* Level 2: Glasses */}
        {level === 2 && (
          <g stroke="#38bdf8" strokeWidth="1.6" fill="none">
            <circle cx="24" cy="33" r="5" />
            <circle cx="40" cy="33" r="5" />
            <line x1="29" y1="33" x2="35" y2="33" />
          </g>
        )}
        {/* Level 3: Neon Headband */}
        {level === 3 && (
          <path d="M16 26 Q32 21 48 26" stroke="#a3e635" strokeWidth="3" strokeLinecap="round" fill="none" />
        )}
        {/* Level 4: Scholar Cap */}
        {level === 4 && (
          <g>
            <polygon points="32,8 16,15 32,22 48,15" fill="#a855f7" />
            <rect x="24" y="18" width="16" height="4" rx="1" fill="#7e22ce" />
          </g>
        )}
        {/* Level 5: Golden Crown */}
        {level >= 5 && (
          <polygon points="20,21 24,11 32,17 40,11 44,21" fill="#facc15" stroke="#ca8a04" strokeWidth="1" />
        )}
      </svg>
    </div>
  );
};
