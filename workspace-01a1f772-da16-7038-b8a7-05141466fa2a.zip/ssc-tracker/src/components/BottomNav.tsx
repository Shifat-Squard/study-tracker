import React from 'react';
import type { NavTab } from '../types/study';
import { Home, Play, BarChart3, Trophy, User } from 'lucide-react';

interface BottomNavProps {
  activeTab: NavTab;
  onChange: (tab: NavTab) => void;
  hasActiveSession: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChange,
  hasActiveSession,
}) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 px-4 pb-3 pt-1 pointer-events-none">
      <div className="max-w-md mx-auto glass-card-strong rounded-3xl px-4 py-2 flex items-center justify-between pointer-events-auto shadow-[0_-4px_32px_rgba(0,0,0,0.5)]">
        <button
          onClick={() => onChange('home')}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition ${
            activeTab === 'home' ? 'text-lime-400' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Home</span>
        </button>

        <button
          onClick={() => onChange('study')}
          aria-label="Study"
          className="relative -mt-6 flex flex-col items-center"
        >
          <div
            className={`w-14 h-14 rounded-full flex items-center justify-center transition active:scale-95 ${
              activeTab === 'study'
                ? 'bg-lime-300 text-slate-950 shadow-[0_0_28px_rgba(163,230,53,0.75)]'
                : 'bg-lime-400 text-slate-950 shadow-[0_0_20px_rgba(163,230,53,0.45)]'
            }`}
          >
            <Play className="w-6 h-6 fill-slate-950 ml-0.5" />
          </div>
          {hasActiveSession && (
            <span className="absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full bg-rose-500 border-2 border-[#0b0e11] animate-pulse" />
          )}
          <span
            className={`text-[10px] font-bold mt-1 ${
              activeTab === 'study' ? 'text-lime-400' : 'text-slate-300'
            }`}
          >
            Study
          </span>
        </button>

        <button
          onClick={() => onChange('progress')}
          className={`flex flex-col items-center gap-1 px-2.5 py-1.5 rounded-xl transition ${
            activeTab === 'progress' ? 'text-lime-400' : 'text-slate-400 hover:text-white'
          }`}
        >
          <BarChart3 className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Progress</span>
        </button>

        <button
          onClick={() => onChange('ranking')}
          className={`flex flex-col items-center gap-1 px-2.5 py-1.5 rounded-xl transition ${
            activeTab === 'ranking' ? 'text-lime-400' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Trophy className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Ranking</span>
        </button>

        <button
          onClick={() => onChange('profile')}
          className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition ${
            activeTab === 'profile' ? 'text-lime-400' : 'text-slate-400 hover:text-white'
          }`}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-semibold">Profile</span>
        </button>
      </div>
    </nav>
  );
};
