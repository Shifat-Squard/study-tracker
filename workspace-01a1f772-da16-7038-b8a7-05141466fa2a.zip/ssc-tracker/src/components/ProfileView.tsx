import React, { useMemo, useState } from 'react';
import type { Profile, StudySession } from '../types/study';
import { AVATAR_OPTIONS, FoxAvatar } from './FoxMascot';
import { computeAchievements, computePersonalStats, getFoxLevel } from '../lib/gamification';
import { formatHM } from '../lib/time';
import { LogOut, Save, Sparkles, Check, Loader2, Flame, Trophy, Award, Zap } from 'lucide-react';

interface ProfileViewProps {
  profile: Profile;
  sessions: StudySession[];
  email: string;
  onUpdateProfile: (updates: Partial<Profile>) => Promise<void>;
  onRevisitOnboarding: () => void;
  onLogout: () => Promise<void>;
}

const SSC_BATCHES = ['SSC 26', 'SSC 27', 'SSC 28', 'SSC 29'];

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  sessions,
  email,
  onUpdateProfile,
  onRevisitOnboarding,
  onLogout,
}) => {
  const [studentName, setStudentName] = useState(profile.student_name);
  const [sscBatch, setSscBatch] = useState(profile.ssc_batch);
  const [schoolName, setSchoolName] = useState(profile.school_name ?? '');
  const [avatarId, setAvatarId] = useState(profile.avatar_id);
  const [rankingOptIn, setRankingOptIn] = useState(profile.ranking_opt_in ?? true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const stats = useMemo(() => computePersonalStats(sessions), [sessions]);
  const foxLevel = useMemo(() => getFoxLevel(stats.totalSeconds), [stats.totalSeconds]);
  const achievements = useMemo(() => computeAchievements(sessions), [sessions]);
  const unlockedCount = achievements.filter((a) => a.unlocked).length;

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim()) return;
    setSaving(true);
    setSaved(false);
    try {
      await onUpdateProfile({
        student_name: studentName.trim(),
        ssc_batch: sscBatch,
        school_name: schoolName.trim() || null,
        avatar_id: avatarId,
        ranking_opt_in: rankingOptIn,
      });
      setSaved(true);
      window.setTimeout(() => setSaved(false), 2500);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="pb-28 pt-5 px-4 max-w-md mx-auto space-y-5 animate-fade-up">
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] font-bold tracking-[0.2em] uppercase text-lime-400 block">
            ব্যক্তিগত প্রোফাইল
          </span>
          <h1 className="text-2xl font-bold text-white">আমার অ্যাকাউন্ট</h1>
        </div>
        <FoxAvatar avatarId={avatarId} size="lg" level={foxLevel.current.level} />
      </div>

      {/* Fox Evolution & XP Card */}
      <div className="glass-card rounded-3xl p-4 space-y-3 border-lime-400/25">
        <div className="flex items-center justify-between">
          <div>
            <span className={`text-xs font-bold ${foxLevel.current.color}`}>
              লেভেল {foxLevel.current.level} · {foxLevel.current.title}
            </span>
            <p className="text-[11px] text-slate-400 mt-0.5">
              আনলকড: {foxLevel.current.accessory}
            </p>
          </div>
          <div className="flex items-center gap-1 bg-lime-400/15 border border-lime-400/30 px-2.5 py-1 rounded-xl">
            <Zap className="w-3.5 h-3.5 text-lime-400" />
            <span className="font-mono-timer text-xs font-bold text-lime-300">
              {profile.xp ?? 0} XP
            </span>
          </div>
        </div>

        <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
          <div
            style={{ width: `${foxLevel.progressPct}%` }}
            className="h-full bg-lime-400 rounded-full transition-all duration-500"
          />
        </div>
        {foxLevel.next && (
          <p className="text-[10px] text-slate-400 text-right">
            পরবর্তী লেভেল ({foxLevel.next.title}): {foxLevel.next.minHours} ঘণ্টা
          </p>
        )}
      </div>

      {/* Personal Stats */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="glass-card rounded-2xl p-3 text-center">
          <Flame className="w-4 h-4 text-orange-400 mx-auto mb-1" />
          <p className="font-mono-timer text-sm font-bold text-white">{stats.currentStreak} দিন</p>
          <p className="text-[10px] text-slate-400">বর্তমান স্ট্রিক</p>
        </div>
        <div className="glass-card rounded-2xl p-3 text-center">
          <Trophy className="w-4 h-4 text-amber-400 mx-auto mb-1" />
          <p className="font-mono-timer text-sm font-bold text-white">
            {formatHM(stats.bestDaySeconds)}
          </p>
          <p className="text-[10px] text-slate-400">সেরা দিন</p>
        </div>
        <div className="glass-card rounded-2xl p-3 text-center">
          <Award className="w-4 h-4 text-lime-400 mx-auto mb-1" />
          <p className="font-mono-timer text-sm font-bold text-white">
            {unlockedCount}/{achievements.length}
          </p>
          <p className="text-[10px] text-slate-400">অ্যাচিভমেন্ট</p>
        </div>
      </div>

      {/* Achievements Collection */}
      <div className="glass-card rounded-3xl p-4 space-y-3">
        <h2 className="text-sm font-bold text-white">অ্যাচিভমেন্ট ব্যাজ</h2>
        <div className="grid grid-cols-2 gap-2">
          {achievements.map((ach) => (
            <div
              key={ach.id}
              className={`rounded-2xl p-2.5 border flex items-center gap-2.5 ${
                ach.unlocked
                  ? 'bg-lime-400/10 border-lime-400/30'
                  : 'bg-white/5 border-white/5 opacity-45'
              }`}
            >
              <span className="text-xl shrink-0">{ach.icon}</span>
              <div className="min-w-0">
                <p className="text-xs font-bold text-white truncate">{ach.title}</p>
                <p className="text-[10px] text-slate-400 truncate">{ach.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Profile Settings Form */}
      <form onSubmit={handleSave} className="glass-card rounded-3xl p-5 space-y-4">
        <div>
          <label className="block text-xs font-medium text-slate-300 mb-2">
            অ্যাভাটার পছন্দ করো
          </label>
          <div className="grid grid-cols-4 gap-2">
            {AVATAR_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setAvatarId(opt.id)}
                className={`p-2 rounded-2xl border flex flex-col items-center gap-1 transition ${
                  avatarId === opt.id
                    ? 'border-lime-400 bg-lime-400/10'
                    : 'border-white/10 bg-white/5 hover:border-white/25'
                }`}
              >
                <FoxAvatar avatarId={opt.id} size="sm" level={foxLevel.current.level} />
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-300 mb-1.5">
            তোমার নাম
          </label>
          <input
            type="text"
            required
            value={studentName}
            onChange={(e) => setStudentName(e.target.value)}
            className="w-full bg-slate-900/80 border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-lime-400/60"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              SSC ব্যাচ
            </label>
            <select
              value={sscBatch}
              onChange={(e) => setSscBatch(e.target.value)}
              className="w-full bg-slate-900/80 border border-white/10 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-lime-400/60"
            >
              {SSC_BATCHES.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              স্কুল (ঐচ্ছিক)
            </label>
            <input
              type="text"
              value={schoolName}
              onChange={(e) => setSchoolName(e.target.value)}
              placeholder="স্কুলের নাম"
              className="w-full bg-slate-900/80 border border-white/10 rounded-xl px-3.5 py-2.5 text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-lime-400/60"
            />
          </div>
        </div>

        <label className="flex items-center justify-between bg-white/5 rounded-xl px-3.5 py-2.5 border border-white/5 cursor-pointer">
          <span className="text-xs text-slate-200">র‍্যাংকিংয়ে অংশগ্রহণ করো</span>
          <input
            type="checkbox"
            checked={rankingOptIn}
            onChange={(e) => setRankingOptIn(e.target.checked)}
            className="accent-lime-400 w-4 h-4"
          />
        </label>

        <div>
          <label className="block text-xs font-medium text-slate-400 mb-1">
            ইমেইল
          </label>
          <p className="text-xs text-slate-300 bg-white/5 rounded-xl px-3.5 py-2.5 border border-white/5">
            {email}
          </p>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3.5 rounded-xl bg-lime-400 hover:bg-lime-300 active:scale-[0.98] disabled:opacity-60 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 transition"
        >
          {saving ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : saved ? (
            <Check className="w-4 h-4" />
          ) : (
            <Save className="w-4 h-4" />
          )}
          <span>{saved ? 'সেভ হয়েছে!' : 'প্রোফাইল সেভ করো'}</span>
        </button>
      </form>

      <div className="space-y-2.5">
        <button
          onClick={onRevisitOnboarding}
          className="w-full glass-card rounded-2xl p-4 flex items-center justify-between text-sm font-medium text-slate-200 hover:text-white transition"
        >
          <span className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-lime-400" />
            অনবোর্ডিং আবার দেখো
          </span>
          <span className="text-xs text-slate-400">→</span>
        </button>

        <button
          onClick={onLogout}
          className="w-full glass-card rounded-2xl p-4 flex items-center justify-between text-sm font-medium text-rose-400 hover:bg-rose-500/10 border-rose-500/20 transition"
        >
          <span className="flex items-center gap-2.5">
            <LogOut className="w-4 h-4" />
            লগআউট করো
          </span>
        </button>
      </div>
    </div>
  );
};
