export type StudyMode = 'focus' | 'youtube';

export type NavTab = 'home' | 'study' | 'progress' | 'ranking' | 'profile';

export type LeaderboardPeriod = 'daily' | 'weekly' | 'monthly' | 'batch';

export interface LeaderboardEntry {
  user_id: string;
  student_name: string;
  ssc_batch: string;
  avatar_id: string;
  focus_seconds: number;
  youtube_seconds: number;
  total_seconds: number;
  xp: number;
  rank: number;
  prev_rank: number | null;
}

export type FoxState = 'sleeping' | 'reading' | 'active' | 'happy';

export interface Profile {
  id: string;
  student_name: string;
  ssc_batch: string;
  school_name: string | null;
  avatar_id: string;
  onboarding_completed: boolean;
  ranking_opt_in?: boolean;
  xp?: number;
  created_at?: string;
  updated_at?: string;
}

export interface ActiveSession {
  user_id: string;
  session_id: string;
  mode: StudyMode;
  started_at: string; // ISO timestamp
}

export interface StudySession {
  id: string;
  user_id: string;
  mode: StudyMode;
  started_at: string;
  ended_at: string;
  duration_seconds: number;
  study_date: string; // YYYY-MM-DD
  created_at?: string;
}
